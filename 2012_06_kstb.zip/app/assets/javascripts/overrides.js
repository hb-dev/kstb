$(document).on("mobileinit", function(){
     $.mobile.defaultPageTransition = 'none';
     $.mobile.defaultDialogTransition = 'none';
     $.mobile.useFastClick = true;
});
