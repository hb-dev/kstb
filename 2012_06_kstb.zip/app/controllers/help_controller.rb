class HelpController < ApplicationController
  def index
  end
end
