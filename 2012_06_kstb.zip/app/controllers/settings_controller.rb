class SettingsController < ApplicationController
  def index
  end
end
