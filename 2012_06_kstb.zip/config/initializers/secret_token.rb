# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Kstb::Application.config.secret_token = 'b5a750abf90199cfde69e2f469847a7b060763978fd7a7a5b08e9075946ee93f0f099b234ae04637fc48caea2c424326e85f533dd190c4b5ccdd07ad36d88236'
