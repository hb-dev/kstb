require 'test_helper'

class TriggerTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
