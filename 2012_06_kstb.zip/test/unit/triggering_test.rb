require 'test_helper'

class TriggeringTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
