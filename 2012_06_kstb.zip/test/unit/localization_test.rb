require 'test_helper'

class LocalizationTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
