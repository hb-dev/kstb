require 'test_helper'

class SettingsHelperTest < ActionView::TestCase
end
