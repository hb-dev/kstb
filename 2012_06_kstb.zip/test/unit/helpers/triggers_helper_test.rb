require 'test_helper'

class TriggersHelperTest < ActionView::TestCase
end
