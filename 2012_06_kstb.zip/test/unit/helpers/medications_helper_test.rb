require 'test_helper'

class MedicationsHelperTest < ActionView::TestCase
end
